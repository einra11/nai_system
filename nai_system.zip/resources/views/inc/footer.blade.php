<footer class="footer navbar-static-top navbar-laravel navbar-dark p-3">
        <div class="container text-center">
          <span class="text-white">National Irrigation Administration <br/> Copyright © 2018. All Rights Reserved</span>
        </div>
      </footer>