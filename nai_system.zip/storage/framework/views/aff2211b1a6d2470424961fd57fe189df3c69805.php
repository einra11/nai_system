<nav class="navbar navbar-expand-md navbar-dark navbar-laravel">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <img src="/storage/web_imgs/logo1.png" width="50" height="50" class="d-inline-block align-bottom" alt="">
                <strong>NIA</strong>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <!-- Left Side Of Navbar -->
                <ul class="navbar-nav mr-auto">
                        
                </ul>

                <!-- Right Side Of Navbar -->
                <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                                <a class="nav-link" href="/">Home <span class="sr-only">(current)</span></a>
                        </li> 
                        <li class="nav-item active">
                            <a class="nav-item nav-link" href="/services">Services</a>
                        </li>
                        <li class="nav-item active">
                                <a class="nav-item nav-link" href="/gallery">Gallery</a>
                        </li>
                        <li class="nav-item active">
                                <a class="nav-item nav-link" href="/about">About</a>
                        </li>
                    <!-- Authentication Links -->
                    <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>
                        <li class="nav-item">
                            <?php if(Route::has('register')): ?>
                                <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                            <?php endif; ?>
                        </li>
                    <?php else: ?>
                    <?php if(Auth::user()->hasRole('Client')): ?>
                        <li class="nav-item active">
                                <a class="nav-item nav-link" href="/contact">Contact</a>
                        </li>
                        <?php endif; ?>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <i class="fa fa-user-circle fa-2x" aria-hidden="true"></i>
                            </a>

                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <h6 class="dropdown-header"><?php echo e(Auth::user()->name); ?></h6>
                                <?php if(Auth::user()->hasAnyRole([
                                    'Admin',
                                    'Maintenance Department',
                                    'Irrigation Association',
                                    'Contstruction Structures',
                                    'Billing',
                                    'Permits'
                                ])): ?>
                                <a class="dropdown-item" href="/dashboard">
                                <i class="fa fa-user" aria-hidden="true"></i>
                                Dashboard
                                </a>
                                <?php endif; ?>
                                <?php if(Auth::user()->hasRole('Admin')): ?>
                                <a class="dropdown-item" href="/publish">
                                    <i class="fa fa-linode" aria-hidden="true"></i>
                                    Publish
                                </a>
                                <?php endif; ?>
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                                    <i class="fa fa-sign-out" aria-hidden="true"></i>
                                    <?php echo e(__('Logout')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>