<?php $__env->startSection('content'); ?>
<div class="container mb-5">
          <main-app
          :user="<?php echo e(json_encode(Auth::user())); ?>"
          >
        </main-app>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>