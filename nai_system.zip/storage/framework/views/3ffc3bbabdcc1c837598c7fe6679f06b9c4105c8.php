<?php $__env->startSection('content'); ?>
    <div class="container container-boxes">
            <header id="fh5co-header" role="banner">
                    <div class="header-inner">
                        <h1>Gallery</h1>
                    </div>
            </header>
            <div class="row featurette pb-3">
                <?php $__currentLoopData = $publish; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $published): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 mt-2">
                <div class="card">
                        <img class="card-img-top" src="/storage/web_gallery/<?php echo e($published->fileUpload); ?>" width="100%">
                </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
    </div>

      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>