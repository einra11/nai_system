<?php $__env->startSection('content'); ?>
    <div class="container container-boxes">
            <div id="fh5co-contact-section">
                <div class="container py-5 mb-5">
                    <div class="row">
                        <div class="col-md-3">
                            <h3>Contact Info.</h3>
                            <ul class="contact-info" style="list-style:none;">
                                <li><i class="fa fa-map-marker" aria-hidden="true"></i></i> Camias Extension Street, General Santos City, South Cotabato</li>
                                <li><i class="fa fa-phone" aria-hidden="true"></i> </i> +63(83)5522418</li>
                                <li><i class="sl-icon-envelope-open"></i><a href="#"> niagensanarea@gmail.com</a></li>
                                <div class="">
                                    <h3>Follow Us</h3>
                                    <ul class="fh5co-social" style="list-style:none;">
                                        <li><a href="https://web.facebook.com/National-Irrigation-Administration-Region-12-1851407228266699/?modal=admin_todo_tour&ref=admin_to_do_step_controller"><i class="fa fa-facebook" aria-hidden="true"></i> Facebook</a></li>
                                    </ul>
                                </div>
                            </ul>
                        </div>
                        <div class="col-md-8 col-md-push-1 col-sm-12 col-sm-push-0 col-xs-12 col-xs-push-0">
                        <form method="POST" action="<?php echo e(route('contact.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                    <input name="cntName" class="form-control" type="text" value="<?php echo e(Auth::user()->name); ?>" readonly required />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input name="cntEmail" class="form-control" value="<?php echo e(Auth::user()->email); ?>" type="text" readonly required />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input name="cntPhoneNumber" class="form-control" placeholder="Phone Number" type="text" required />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                        <div class="form-group">
                                                <select name="cntDepartment"class="form-control">
                                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($role->name !='Admin'): ?>
                                                        <?php if($role->name !='Client'): ?>
                                                        <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                                                        <?php endif; ?>
                                                        <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                        </div>
                                    </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                            <select name="cntBarangay" class="form-control">
                                                <?php $__currentLoopData = $barangays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barangay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option><?php echo e($barangay->b_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <textarea name="cntMessage" class="form-control" id="" cols="30" rows="7" placeholder="Message" required ></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <input value="Send Message" name="btnSubmit" class="btn btn-primary" type="submit" required />
                                    </div>
                                </div>
                            </div>
                        </form>
                        </div>
                    </div>
                </div>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>