<?php $__env->startSection('content'); ?>
    <div class="container container-boxes">
            <div class="row featurette pb-3">
                    <div class="col-md-12 mt-2">
                            <img src="/storage/web_imgs/img1.png" width="100%" alt="">
                            <hr>
                    </div>
                        <div class="col-md-8 pt-4 pr-1">
                                <h1 class="text-center mb-0"> <img src="/storage/web_imgs/logo1.png" width="60" alt="">National Irrigation Administration</h1>
                                <h5 class="text-center mt-0">General Santos City</h5>
                                <?php $__currentLoopData = $publish; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $published): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card">
                            <img class="card-img-top" src="/storage/web_gallery/<?php echo e($published->fileUpload); ?>" width="100%">
                                    <div class="card-body">
                                      <h5 class="card-title"><?php echo e($published->title); ?></h5>
                                      <h6 class="card-subtitle mb-2 text-muted"><?php echo e($published->created_at); ?></h6>
                                      <p class="card-text text-justify">"<?php echo e($published->body); ?>"</p>
                                      <a href="#" class="card-link">See more</a>
                                    </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($publish->links()); ?>

                        </div>
                        <div class="col-md-4 pl-0 pr-1 pt-2">
                                <clock-app class="my-0"></clock-app>
                                <div class="card">
                                        <img class="card-img-top" src="/storage/web_imgs/img2.png" width="100%">
                                        <div class="card-body">
                                                <h5 class="card-title">Mission and Vision</h5>
                                                <br>
                                                <h6 class="card-subtitle mb-2 text-muted text-center">Mission</h6>
                                                <p class="card-text text-justify">"To construct,operate ,and maintain irrigation systems consistent with integrated
                                                                                water resource management principles to improve agricultural productivity and increase farmers income."</p>
                                                <h6 class="card-subtitle mb-2 text-muted text-center">Vision</h6>
                                                <p class="card-text text-justify">"By 2020, NIA is a professional and efficient irrigation agency contributing
                                                                to inclusive growth of the country and in the improvement of the farmers quality of life."</p>
                                        </div>
                                </div> 
                        </div>                        
            </div>
    </div>

      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>