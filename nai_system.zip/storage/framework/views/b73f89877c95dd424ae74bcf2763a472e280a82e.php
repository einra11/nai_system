<?php if(count($errors) > 0): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">
                <i class="fa fa-exclamation-circle fa-2x" aria-hidden="true"></i>
                <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
            <?php echo e($error); ?>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(session('success')): ?>
        <div class="alert alert-success">
            <i class="fa fa-exclamation-circle fa-3x" aria-hidden="true"></i>
            <?php echo e(session('success')); ?>

        </div>
<?php endif; ?>

<?php if(session('error')): ?>
        <div class="alert alert-danger">
            <i class="fa fa-exclamation-circle fa-3x" aria-hidden="true"></i>
            <?php echo e(session('error')); ?>

        </div>
<?php endif; ?>